<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <title>Require a Drawn Signature · Signature Pad</title>
  <script src="<?php echo e(asset('signature_pad/assets/json2.min.js')); ?>"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://unpkg.com/jspdf@latest/dist/jspdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/numeric/1.2.6/numeric.min.js"></script>
    <script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>
    <script type='text/javascript' src="https://cdn.jsdelivr.net/npm/watermarkjs@2.0.0/dist/watermark.min.js"></script>

  <style>
    body { font: normal 100.01%/1.375 "Helvetica Neue",Helvetica,Arial,sans-serif; }
  </style>
  <link href="<?php echo e(asset('signature_pad/assets/jquery.signaturepad.css')); ?>" rel="stylesheet">
  <!--[if lt IE 9]><script src="<?php echo e(asset('assets/flashcanvas.js')); ?>"></script><![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
</head>
<body>


<img src="" id="signImage" height="200" width="400"/>

        <img src="<?php echo e(asset('main.jpg')); ?>" id="mainImage" height="200" width="400" />

<button id="download"><a class="link" href="" download>Click to Download</a></button>

  <form method="post" action="#" class="sigPad">
    <label for="name">Print your name</label>
    <input type="text" name="name" id="name" class="name">
    <p class="drawItDesc">Draw your signature</p>
    <ul class="sigNav">
      <li class="drawIt"><a href="#draw-it" >Draw It</a></li>
      <li class="clearButton"><a href="#clear">Clear</a></li>
    </ul>



    <div class="sig sigWrapper">
      <div class="typed"></div>
      <canvas id="sign-pad" class="pad" width="198" height="55"></canvas>

        

      <input type="hidden" name="output" class="output">
    </div>
    <button id="btnSaveSign" type="button">Submit your Signature.</button>
  </form>
    <!-- <div id="imagePreview"><img src="#"></div> -->
  <script src="<?php echo e(asset('signature_pad/jquery.signaturepad.js')); ?>"></script>
  <script>

    $('#signArea').signaturePad({drawOnly:true, lineTop:190});
            
            $("#btnSaveSign").click(function(e){
                html2canvas([document.getElementById('sign-pad')], {
                    onrendered: function (canvas) {
                        var canvas_img_data = canvas.toDataURL();
                        var img_data = canvas_img_data.replace(/^data:image\/(png|jpg);base64,/, "");
                        //ajax call to save image inside folder
                        //var image = document.createElement('img');

                        //alert('coming');
            
                        // image.src=canvas_img_data;
            
                        // image.width=300;
                        // image.height=100;
                        // image.alt="here should be some image";
            
                        $("#signImage").attr('src', canvas_img_data);
            
                        var elemImg = document.getElementById('mainImage');
                        watermarkImage(elemImg, canvas_img_data);
            
                    }
                });
            });
            
            
            function watermarkImage(elemImage, text) {
             
              // Create test image to get proper dimensions of the image.
                var testImage = new Image();
                testImage.setAttribute('crossOrigin', 'anonymous');
                testImage.onload = function() {
                    var h = testImage.height, w = testImage.width, img = new Image();
                    img.setAttribute('crossOrigin', 'anonymous');
                    
                    // Once the image with the SVG of the watermark is loaded...
                    img.onload = function() {
                        // Make canvas with image and watermark
                        var canvas = Object.assign(document.createElement('canvas'), {width: w, height: h});
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(testImage, 0, 0);
                        ctx.drawImage(img, 700, 1100);
                        try {
                              elemImage.src = canvas.toDataURL('image/png');
                              $('.link').attr("href",canvas.toDataURL('image/jpeg')).attr("download", "Document.jpeg");
                            }
                        catch (e) {
                          console.log(e);
                            console.error('Cannot watermark image with text:', {src: elemImage.src, text: text, error: e});
                          }
                    };
                    // SVG image watermark (HTML of text at bottom right)
                    img.src = text;
                    // alert(img.src);
                };
               
                testImage.src = elemImage.src;
                $("#download").show();
                s
               
            }

    $(document).ready(function() {
      $("#download").hide();
      $('.sigPad').signaturePad({drawOnly:true});
    });
  </script>
  
</body><?php /**PATH /var/www/html/digital_signature/resources/views/sign7.blade.php ENDPATH**/ ?>