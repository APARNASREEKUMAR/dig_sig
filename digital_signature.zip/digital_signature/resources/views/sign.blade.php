@extends('layouts.app')
@section('content')
  
        <div class="container">
            <img src="{{ asset('main.jpg') }}" alt="Main Document" width="600" height="600" align="middle">
            <hr>
        <button id="sign" class="btn btn-primary offset-3">Click here to sign the Document</button>
        </div>

    <!-- <div data-role="popup"id="divPopUpSignContract">
		<div data-role="header"data-theme="b">
			<a data-role="button"data-rel="back"data-transition="slide"class="ui-btn-right"onclick="closePopUp()"> Close </a>
			<p class="popupHeader">Sign Pad</p>
		</div>
		<div class="ui-content popUpHeight">
			<div id="div_signcontract">
				<canvas id="canvas">Canvas is not supported</canvas>
				<div>
					<input id="btnSubmitSign"type="button"data-inline="true"data-mini="true"data-theme="b"value="Submit Sign"onclick="fun_submit()"/>
					<input id="btnClearSign"type="button"data-inline="true"data-mini="true"data-theme="b"value="Clear"onclick="init_Sign_Canvas()"/>
				</div>
			</div>	
		</div>
	</div> -->

<div class="container">
  <h2>Modal Example</h2>
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add your Digital Signature</h4>
        </div>
        <div class="modal-body">
        <canvas id="can">Canvas is not supported</canvas>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

@endsection   
@section('scripts')
<script>
    $(document).ready(function() {
        $('#sign').click(function(){ });
       
    });
</script>
@endsection