<!DOCTYPE html> 
	<head>
		<script src="jquery-1.9.1.min.js"></script>
		<link rel="StyleSheet" href="watermarker.css" type="text/css">
		<link rel="StyleSheet" href="demo.css" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/canvasjs/1.7.0/jquery.canvasjs.min.js"></script>
    </head>
	<body>
		<div class="container">
			<div class= "image" id="main_image">
				<img src="main.jpg" id="image" >
			</div>			
		</div>
		<div class= "info-container">
			<div class="info">
				<label>X</label>
				<input type="text" id="posx">
				<label>Y</label>
				<input type="text" id="posy">
				<br><br>
				<label>Width</label>
				<input type="text" id="width">
				<label>Height</label>
				<input type="text" id="height">
				<br><br>
				<label>Opacity</label>
				<input type="text" id="opacity"><br><br>
				<label>Mouse X</label>
				<input type="text" id="mousex"><br><br>
				<label>Mouse Y</label>
				<input type="text" id="mousey">	
                <input id="btn-Preview-Image" type="button" value="Preview"/>
    <a id="btn-Convert-Html2Image" href="#">Download</a>
    <br/>
    <h3>Preview :</h3>
    <div id="previewImage">
    </div>
			</div>	
            	
		</div>
	</body>
	<script src="watermarker.js" type="text/javascript"></script>
	<script src="demo.js" type="text/javascript"></script>
    <script>
    $(document).ready(function(){
       
	
var element = $("#main_image"); // global variable
var getCanvas; // global variable
 
            $("#btn-Preview-Image").on('click', function () {
                html2canvas(element, {
                onrendered: function (canvas) {
                        $("#previewImage").append(canvas);
                        getCanvas = canvas;
                    }
                });
            });

            $("#btn-Convert-Html2Image").on('click', function () {
            var imgageData = getCanvas.toDataURL("image/png");
            // Now browser starts downloading it instead of just showing it
            var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
            $("#btn-Convert-Html2Image").attr("download", "your_pic_name.png").attr("href", newData);
            });

        });
    
    </script>
</html>